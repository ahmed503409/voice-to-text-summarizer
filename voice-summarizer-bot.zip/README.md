
# Voice-to-Text Summarizer Bot using Generative AI

This application takes an audio file (MP3/WAV), transcribes it to text using Whisper or SpeechRecognition, and summarizes it using a Hugging Face T5 transformer model.

## Features
- Upload MP3/WAV files
- Transcribe audio using OpenAI Whisper or SpeechRecognition
- Summarize long-form text using T5
- Streamlit web interface

## Setup

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Sample Test File
Use the audio file in `sample_audio/sample.mp3` for demo.

