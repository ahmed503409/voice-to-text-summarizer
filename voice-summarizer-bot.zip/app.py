
import streamlit as st
from transcriber import transcribe_audio
from summarizer import summarize_text

st.title("🎙️ Voice-to-Text Summarizer Bot")

uploaded_file = st.file_uploader("Upload an audio file (MP3/WAV)", type=["mp3", "wav"])
if uploaded_file:
    with open("temp_audio", "wb") as f:
        f.write(uploaded_file.read())

    st.info("Transcribing...")
    text = transcribe_audio("temp_audio")
    st.success("Transcription Complete!")
    st.text_area("Transcribed Text", text, height=200)

    st.info("Summarizing...")
    summary = summarize_text(text)
    st.success("Summary Ready!")
    st.text_area("Summary", summary, height=150)
