
from transformers import pipeline

summarizer = pipeline("summarization", model="t5-base")

def summarize_text(text):
    if len(text) < 30:
        return "Text too short to summarize."
    result = summarizer(text, max_length=100, min_length=30, do_sample=False)
    return result[0]["summary_text"]
